package com.spring.helloworld;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {
	@RequestMapping(value="/")
	public String getHelloWorld()
	{
		return "Welcome to SpringBoot through Spring Approach";
	}
	//@RequestMapping(value="/hello2")
	//public String getHelloWorld_New()
	//{
		//return "Welcome to SpringBoot through Spring Approach";
	//}


}
