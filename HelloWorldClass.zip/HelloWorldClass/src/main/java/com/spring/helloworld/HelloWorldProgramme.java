package com.spring.helloworld;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//Boot Strap Class

//Updating the JVM to start from here.
@SpringBootApplication
public class HelloWorldProgramme {

public static void main(String[] args) {
		// TODO Auto-generated method stub
	SpringApplication.run(HelloWorldProgramme.class, args);
	//HelloWorldController hello= new  HelloWorldController();
	//hello.getHelloWorld();

	}

}
